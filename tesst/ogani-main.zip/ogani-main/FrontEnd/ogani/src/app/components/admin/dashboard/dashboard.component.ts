import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
// @ts-ignore
import { faFaceLaughWink, faTag } from '@fortawesome/free-solid-svg-icons';
// @ts-ignore
import {faSearch} from '@fortawesome/free-solid-svg-icons'
// @ts-ignore
import {faBell} from '@fortawesome/free-solid-svg-icons'
// @ts-ignore
import {faEnvelope} from '@fortawesome/free-solid-svg-icons'
// @ts-ignore
import {faTachometerAlt} from '@fortawesome/free-solid-svg-icons'
// @ts-ignore
import {faBookmark} from '@fortawesome/free-solid-svg-icons'
// @ts-ignore
import {faReceipt} from '@fortawesome/free-solid-svg-icons'
// @ts-ignore
import {faCartShopping} from '@fortawesome/free-solid-svg-icons'
// @ts-ignore
import {faRocket} from '@fortawesome/free-solid-svg-icons'
// @ts-ignore
import {faUser} from '@fortawesome/free-solid-svg-icons'
// @ts-ignore
import {faBars} from '@fortawesome/free-solid-svg-icons'
// @ts-ignore
import {faPaperPlane} from '@fortawesome/free-solid-svg-icons'
// @ts-ignore
import {faGear} from '@fortawesome/free-solid-svg-icons'
// @ts-ignore
import {faRightFromBracket} from '@fortawesome/free-solid-svg-icons'
import { AuthService } from 'src/app/_service/auth.service';
import { StorageService } from 'src/app/_service/storage.service';



@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit{
  faceLaugh = faFaceLaughWink;
  search = faSearch
  bell = faBell;
  evelope =faEnvelope;
  tachometer = faTachometerAlt;
  bookmark = faBookmark;
  receipt = faReceipt;
  cart= faCartShopping;
  rocket = faRocket;
  userIcon = faUser;
  paperPlane = faPaperPlane;
  bars = faBars;
  gear = faGear;
  logoutIcon = faRightFromBracket;
  tag = faTag;

  constructor(private storageService:StorageService,private authService:AuthService,private router: Router){}

  ngOnInit(): void {
  }


  logout(){
    this.authService.logout().subscribe({
      next: res =>{
        this.storageService.clean();
        this.router.navigate(['/']);
      }
    })
  }



}
